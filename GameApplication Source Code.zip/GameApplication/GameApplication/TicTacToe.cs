﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GameApplication
{
    public partial class TicTacToe : Form
    {
        private char currentPlayer;
        private char[,] board;
        private Button[,] buttons;
        public static string user;

        public TicTacToe()
        {
            InitializeComponent();
            InitializeBoard();
            user = Dashboard.SetValueForText3;
            label2.Text = user;
            con = new SqlConnection("Data Source=LAPTOP-ATG56U89;Initial Catalog=GameApp;Integrated Security=True");
        }
        SqlConnection con;
        SqlCommand cmd;
        private void InitializeBoard()
        {
            currentPlayer = 'X';
            board = new char[3, 3];
            buttons = new Button[3, 3]
            {
                { button1, button2, button3 },
                { button4, button5, button6 },
                { button7, button8, button9 }
            };

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    buttons[i, j].Text = "";
                    buttons[i, j].Enabled = true;
                    buttons[i, j].Tag = i * 3 + j; // Assigning Tag property with row and column value
                    board[i, j] = '\0';
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;
                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;
                playerName = user;
                status = "draw";
                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "win";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                   
                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "win";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {

                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            int row = (int)button.Tag / 3;
            int col = (int)button.Tag % 3;

            if (board[row, col] != '\0')
                return;

            board[row, col] = currentPlayer;
            button.Text = currentPlayer.ToString();
            button.Enabled = false;

            if (CheckWin(currentPlayer))
            {
                MessageBox.Show($"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "win";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            if (CheckDraw())
            {
                MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                String status, playerName;

                status = "draw";

                playerName = user;

                try
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                    cmd.Parameters.AddWithValue("b", status);
                    cmd.Parameters.AddWithValue("c", playerName);




                    int i = cmd.ExecuteNonQuery();

                    if (i == 1)
                        MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                InitializeBoard();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';

            // Computer's turn
            if (currentPlayer == 'O')
            {
                var bestMove = GetBestMove(board);
                int compRow = bestMove.Item1;
                int compCol = bestMove.Item2;

                board[compRow, compCol] = currentPlayer;
                buttons[compRow, compCol].Text = currentPlayer.ToString();
                buttons[compRow, compCol].Enabled = false;

                if (CheckWin(currentPlayer))
                {
                    MessageBox.Show($"Player {currentPlayer} wins!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "lose";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                if (CheckDraw())
                {
                    MessageBox.Show("It's a draw!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    String status, playerName;

                    status = "draw";

                    playerName = user;

                    try
                    {
                        con.Open();
                        cmd = new SqlCommand("Insert into TicTacToe values ( @b, @c)", con);
                        cmd.Parameters.AddWithValue("b", status);
                        cmd.Parameters.AddWithValue("c", playerName);




                        int i = cmd.ExecuteNonQuery();

                        if (i == 1)
                            MessageBox.Show(this, "Data save Successfully", "Infromation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show(this, "Data Cannot Save", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        con.Close();
                        cmd.Dispose();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(this, "Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Error, Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    InitializeBoard();
                    return;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }
        private bool CheckWin(char player)
        {
            // Check rows
            for (int row = 0; row < 3; row++)
            {
                if (board[row, 0] == player && board[row, 1] == player && board[row, 2] == player)
                    return true;
            }

            // Check columns
            for (int col = 0; col < 3; col++)
            {
                if (board[0, col] == player && board[1, col] == player && board[2, col] == player)
                    return true;
            }

            // Check diagonals
            if (board[0, 0] == player && board[1, 1] == player && board[2, 2] == player)
                return true;

            if (board[2, 0] == player && board[1, 1] == player && board[0, 2] == player)
                return true;

            return false;
        }

        private bool CheckDraw()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (board[row, col] == '\0')
                        return false;
                }
            }
            return true;
        }

        private Tuple<int, int> GetBestMove(char[,] currentBoard)
        {
            int bestScore = int.MinValue;
            Tuple<int, int> bestMove = null;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (currentBoard[i, j] == '\0')
                    {
                        currentBoard[i, j] = currentPlayer;
                        int score = Minimax(currentBoard, 0, false);
                        currentBoard[i, j] = '\0';

                        if (score > bestScore)
                        {
                            bestScore = score;
                            bestMove = Tuple.Create(i, j);
                        }
                    }
                }
            }

            return bestMove;
        }

        private int Minimax(char[,] currentBoard, int depth, bool isMaximizing)
        {
            if (CheckWin('X'))
                return -1;
            if (CheckWin('O'))
                return 1;
            if (CheckDraw())
                return 0;

            if (isMaximizing)
            {
                int bestScore = int.MinValue;

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (currentBoard[i, j] == '\0')
                        {
                            currentBoard[i, j] = 'O';
                            int score = Minimax(currentBoard, depth + 1, false);
                            currentBoard[i, j] = '\0';

                            bestScore = Math.Max(score, bestScore);
                        }
                    }
                }

                return bestScore;
            }
            else
            {
                int bestScore = int.MaxValue;

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (currentBoard[i, j] == '\0')
                        {
                            currentBoard[i, j] = 'X';
                            int score = Minimax(currentBoard, depth + 1, true);
                            currentBoard[i, j] = '\0';

                            bestScore = Math.Min(score, bestScore);
                        }
                    }
                }

                return bestScore;
            }
        }
    }
}