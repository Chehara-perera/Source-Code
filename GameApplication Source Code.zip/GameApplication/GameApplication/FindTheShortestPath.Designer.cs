﻿
namespace GameApplication
{
    partial class FindTheShortestPath
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_distance = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_shortestpath = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.gameApplicationDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gameApplicationDataSet = new GameApplication.GameApplicationDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.lbl_heading = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.startCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distanceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cityTableAdapter = new GameApplication.GameApplicationDataSetTableAdapters.CityTableAdapter();
            this.distanceTableAdapter = new GameApplication.GameApplicationDataSetTableAdapters.DistanceTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.gameApplicationDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameApplicationDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.distanceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(115, 119);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(134, 18);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Name of the player : ";
            // 
            // lbl_distance
            // 
            this.lbl_distance.AutoSize = true;
            this.lbl_distance.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_distance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_distance.Location = new System.Drawing.Point(327, 439);
            this.lbl_distance.Name = "lbl_distance";
            this.lbl_distance.Size = new System.Drawing.Size(143, 13);
            this.lbl_distance.TabIndex = 2;
            this.lbl_distance.Text = "Distance between cities";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(255, 119);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(406, 20);
            this.txt_name.TabIndex = 3;
            // 
            // txt_shortestpath
            // 
            this.txt_shortestpath.Location = new System.Drawing.Point(255, 518);
            this.txt_shortestpath.Name = "txt_shortestpath";
            this.txt_shortestpath.Size = new System.Drawing.Size(406, 20);
            this.txt_shortestpath.TabIndex = 5;
            // 
            // btn_submit
            // 
            this.btn_submit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submit.Location = new System.Drawing.Point(615, 585);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(143, 36);
            this.btn_submit.TabIndex = 6;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = false;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // gameApplicationDataSetBindingSource
            // 
            this.gameApplicationDataSetBindingSource.DataSource = this.gameApplicationDataSet;
            this.gameApplicationDataSetBindingSource.Position = 0;
            // 
            // gameApplicationDataSet
            // 
            this.gameApplicationDataSet.DataSetName = "GameApplicationDataSet";
            this.gameApplicationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(138, 521);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Shortest Path : ";
            // 
            // btn_calculate
            // 
            this.btn_calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate.Location = new System.Drawing.Point(454, 585);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(143, 36);
            this.btn_calculate.TabIndex = 9;
            this.btn_calculate.Text = "Calculate";
            this.btn_calculate.UseVisualStyleBackColor = false;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // lbl_heading
            // 
            this.lbl_heading.AutoSize = true;
            this.lbl_heading.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_heading.Font = new System.Drawing.Font("Ravie", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_heading.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_heading.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_heading.Location = new System.Drawing.Point(224, 37);
            this.lbl_heading.Name = "lbl_heading";
            this.lbl_heading.Size = new System.Drawing.Size(373, 30);
            this.lbl_heading.TabIndex = 11;
            this.lbl_heading.Text = "Find the Shortest Path!";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startCityDataGridViewTextBoxColumn,
            this.endCityDataGridViewTextBoxColumn,
            this.distanceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.distanceBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(229, 184);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(343, 252);
            this.dataGridView1.TabIndex = 12;
            // 
            // startCityDataGridViewTextBoxColumn
            // 
            this.startCityDataGridViewTextBoxColumn.DataPropertyName = "StartCity";
            this.startCityDataGridViewTextBoxColumn.HeaderText = "StartCity";
            this.startCityDataGridViewTextBoxColumn.Name = "startCityDataGridViewTextBoxColumn";
            // 
            // endCityDataGridViewTextBoxColumn
            // 
            this.endCityDataGridViewTextBoxColumn.DataPropertyName = "EndCity";
            this.endCityDataGridViewTextBoxColumn.HeaderText = "EndCity";
            this.endCityDataGridViewTextBoxColumn.Name = "endCityDataGridViewTextBoxColumn";
            // 
            // distanceDataGridViewTextBoxColumn
            // 
            this.distanceDataGridViewTextBoxColumn.DataPropertyName = "Distance";
            this.distanceDataGridViewTextBoxColumn.HeaderText = "Distance";
            this.distanceDataGridViewTextBoxColumn.Name = "distanceDataGridViewTextBoxColumn";
            // 
            // distanceBindingSource
            // 
            this.distanceBindingSource.DataMember = "Distance";
            this.distanceBindingSource.DataSource = this.gameApplicationDataSetBindingSource;
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.gameApplicationDataSetBindingSource;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // distanceTableAdapter
            // 
            this.distanceTableAdapter.ClearBeforeFill = true;
            // 
            // FindTheShortestPath
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::GameApplication.Properties.Resources.grey_abstract_background_wallpaper_design_free_vector;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(793, 670);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbl_heading);
            this.Controls.Add(this.btn_calculate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.txt_shortestpath);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_distance);
            this.Controls.Add(this.lbl_name);
            this.Name = "FindTheShortestPath";
            this.RightToLeftLayout = true;
            this.Load += new System.EventHandler(this.FindTheShortestPath_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gameApplicationDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameApplicationDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.distanceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_distance;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.BindingSource gameApplicationDataSetBindingSource;
        private GameApplicationDataSet gameApplicationDataSet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.Label lbl_heading;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_shortestpath;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private GameApplicationDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.BindingSource distanceBindingSource;
        private GameApplicationDataSetTableAdapters.DistanceTableAdapter distanceTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn distanceDataGridViewTextBoxColumn;
    }
}

